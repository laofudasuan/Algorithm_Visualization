import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';

function limit(val, min, max) {
  return Math.max(min, Math.min(max, val));
}

export default function GraphD3({ nodes, edges, directed, width = 500, height = 400, nodeRadius = 20, arrowSize = 6, edgeWidth = 2, chargeStrength = -300, onNodeClick }) {
  const ref = useRef();
  const simulationRef = useRef();
  const nodeObjsRef = useRef([]);
  const edgesRef = useRef([]);
  const linkRef = useRef(null);
  const selfLoopRef = useRef(null);
  const linkLabelRef = useRef(null);
  const selfLoopLabelRef = useRef(null);
  const nodeRef = useRef(null);

  // 重建图形的函数
  const rebuildGraph = () => {
    console.log("触发重建函数");
    const svg = d3.select(ref.current);
    svg.selectAll('*').remove();
    svg.attr('width', width).attr('height', height);

    // 创建一个映射来保存现有节点的位置信息
    const existingNodeMap = new Map();
    nodeObjsRef.current.forEach(node => {
      existingNodeMap.set(node.id, node);
    });

    // 过滤无效点和边，节点结构为 {id, fixed, label, x,y, idx}
    const nodeObjs = nodes
      .map((n, i) => ({ ...n, idx: i }))
      .filter(n => n.id)
      .map((n, i, arr) => {
        // 检查是否是已存在的节点
        const existingNode = existingNodeMap.get(n.id);
        
        // 对于fixed节点，优先保持其原有位置
        if (n.fixed) {
          let x, y;
          // 如果是已存在的fixed节点，保持其当前位置
          if (existingNode && existingNode.fixed) {
            x = existingNode.x;
            y = existingNode.y;
          } else {
            // 新的fixed节点或从非fixed变为fixed的节点
            x = n.x !== undefined ? n.x : width / 2 + (nodeRadius * 2 + 10) * Math.cos((2 * Math.PI * i) / Math.max(1, arr.length));
            y = n.y !== undefined ? n.y : height / 2 + (nodeRadius * 2 + 10) * Math.sin((2 * Math.PI * i) / Math.max(1, arr.length));
          }
          
          // 检查边界，确保fixed节点不会超出画布范围
          const margin = nodeRadius + 8;
          x = Math.max(margin, Math.min(width - margin, x));
          y = Math.max(margin, Math.min(height - margin, y));
          
          return {
            ...n,
            x: x,
            y: y,
            fx: x,
            fy: y
          };
        } else {
          // 对于非fixed节点，使用默认的初始化逻辑
          const x = n.x !== undefined ? n.x : width / 2 + (nodeRadius * 2 + 10) * Math.cos((2 * Math.PI * i) / Math.max(1, arr.length));
          const y = n.y !== undefined ? n.y : height / 2 + (nodeRadius * 2 + 10) * Math.sin((2 * Math.PI * i) / Math.max(1, arr.length));
          
          return {
            ...n,
            x: x,
            y: y,
            fx: null,
            fy: null
          };
        }
      });
    nodeObjsRef.current = nodeObjs;
    const nodeIdSet = new Set(nodeObjs.map(n => n.id));
    // 边结构带 label 和 color
    const edgesForD3 = edges
      .map(e => ({ source: e.from.trim(), target: e.to.trim(), label: e.label, color: e.color }))
      .filter(e => e.source && e.target && nodeIdSet.has(e.source) && nodeIdSet.has(e.target));
    edgesRef.current = edgesForD3;

    // D3 force simulation
    const simulation = d3.forceSimulation(nodeObjs)
      .force('link', d3.forceLink(edgesForD3)
        .id(d => d.id)
        .distance(nodeRadius * 5))
      .force('charge', d3.forceManyBody().strength(chargeStrength))
      .force('center', d3.forceCenter(width / 2, height / 2))
      .force('collide', d3.forceCollide(nodeRadius + 8));
    simulationRef.current = simulation;

    // 初始固定点：设置 fx, fy
    nodeObjs.forEach(n => {
      if (n.fixed) {
        n.fx = n.x;
        n.fy = n.y;
      } else {
        n.fx = null;
        n.fy = null;
      }
    });

    // Draw links（分自环和普通边）
    const normalEdges = edgesForD3.filter(e => e.source !== e.target);
    const selfEdges = edgesForD3.filter(e => e.source === e.target);

    const link = svg.append('g')
      .attr('stroke', '#999')
      .attr('stroke-opacity', 0.6)
      .attr('stroke-width', edgeWidth)
      .selectAll('line')
      .data(normalEdges)
      .join('line');
    linkRef.current = link;

    // 自环用 path
    const selfLoop = svg.append('g')
      .attr('stroke', '#999')
      .attr('stroke-opacity', 0.6)
      .attr('stroke-width', edgeWidth)
      .selectAll('path')
      .data(selfEdges)
      .join('path')
      .attr('fill', 'none');
    selfLoopRef.current = selfLoop;

    // 边 label
    const linkLabel = svg.append('g')
      .selectAll('text')
      .data(normalEdges)
      .join('text')
      .attr('font-size', 14)
      .attr('fill', '#333')
      .attr('text-anchor', 'middle')
      .style('pointer-events', 'none')
      .style('user-select', 'none')
      .text(d => d.label || '');
    linkLabelRef.current = linkLabel;

    // 自环 label
    const selfLoopLabel = svg.append('g')
      .selectAll('text')
      .data(selfEdges)
      .join('text')
      .attr('font-size', 14)
      .attr('fill', '#333')
      .attr('text-anchor', 'middle')
      .style('pointer-events', 'none')
      .style('user-select', 'none')
      .text(d => d.label || '');
    selfLoopLabelRef.current = selfLoopLabel;

    // 移除旧的 defs，防止 marker 冲突
    svg.select('defs').remove();
    let markerId = `arrowhead-${Math.random().toString(36).slice(2, 10)}`;
    // Arrowhead marker for directed graph
    if (directed) {
      svg.append('defs').append('marker')
        .attr('id', markerId)
        .attr('viewBox', '0 -5 10 10')
        .attr('refX', nodeRadius+15 - arrowSize)
        .attr('refY', 0)
        .attr('markerWidth', arrowSize)
        .attr('markerHeight', arrowSize)
        .attr('orient', 'auto')
        .append('path')
        .attr('d', 'M0,-5L10,0L0,5')
        .attr('fill', '#999');
    }
    // 每次都刷新 marker-end，使用唯一 id
    const markerUrl = directed ? `url(#${markerId})` : null;
    link.attr('marker-end', markerUrl);

    // Draw nodes
    const node = svg.append('g')
      .selectAll('circle')
      .data(nodeObjs)
      .join('circle')
      .attr('r', nodeRadius)
      .attr('fill', d => d.color || '#69b3a2')
      .attr('stroke', d => d.fixed ? '#000' : '#fff')
      .attr('stroke-width', d => d.fixed ? 3 : 1.5)
      .style('cursor', 'pointer')
      .style('user-select', 'none')
      .on('click', (event, d) => {
        // 阻止事件冒泡，防止触发文本选择
        event.stopPropagation();
        console.log('Node clicked:', d.id);
        
        // 调用父组件的回调函数来切换固定状态
        if (onNodeClick) {
          onNodeClick(d.id);
        }
      })
      .call(d3.drag()
        .on('start', (event, d) => {
          if (!event.active) simulation.alphaTarget(0.3).restart();
          d.fx = d.x;
          d.fy = d.y;
        })
        .on('drag', (event, d) => {
          d.fx = event.x;
          d.fy = event.y;
        })
        .on('end', (event, d) => {
          if (!event.active) simulation.alphaTarget(0);
          // 固定节点拖拽结束后保持固定状态，非固定节点释放
          if (!d.fixed) {
            d.fx = null;
            d.fy = null;
          }
        })
      );
    nodeRef.current = node;

    // Draw labels
    svg.append('g')
      .attr('class', 'node-id-labels')
      .selectAll('text')
      .data(nodeObjs)
      .join('text')
      .attr('text-anchor', 'middle')
      .attr('dy', 5)
      .attr('font-size', Math.max(12, nodeRadius))
      .style('pointer-events', 'none')
      .style('user-select', 'none')
      .text(d => d.id);

    // Draw node labels (自定义label)
    svg.append('g')
      .attr('class', 'node-custom-labels')
      .selectAll('text')
      .data(nodeObjs)
      .join('text')
      .attr('text-anchor', 'start')
      .attr('dx', nodeRadius + 8)
      .attr('dy', 5)
      .attr('font-size', Math.max(12, nodeRadius - 2))
      .attr('fill', '#1976d2')
      .style('pointer-events', 'none')
      .style('user-select', 'none')
      .text(d => d.label || '');

    // 创建一个更新自环元素的函数
    const updateSelfLoops = () => {
      const nodeObjs = nodeObjsRef.current;
      
      if (selfLoopRef.current) {
        selfLoopRef.current
          .attr('d', d => {
            // 自环圆，右上方
            const n = nodeObjs.find(n => n.id === d.source.id || n.id === d.source);
            if (!n) return '';
            const r = nodeRadius;
            const x = limit(n.x, r + 8, width - r - 8);
            const y = limit(n.y, r + 8, height - r - 8);
            // 圆心在节点右上，半径与节点半径相关
            const loopR = r * 0.9 + 10;
            const cx = x + r * 0.7;
            const cy = y - r * 0.7;
            // 圆的起点（3点钟方向），终点（2点钟方向），箭头指向节点
            // 画一整圆，marker-end 会自动加在终点
            return `M${cx + loopR},${cy} A${loopR},${loopR} 0 1,1 ${cx + loopR - 0.01},${cy}`;
          });
      }
      
      // 自环 label 位置
      if (selfLoopLabelRef.current) {
        selfLoopLabelRef.current
          .attr('x', d => {
            const n = nodeObjs.find(n => n.id === d.source.id || n.id === d.source);
            if (!n) return 0;
            const r = nodeRadius;
            const x = limit(n.x, r + 8, width - r - 8);
            return x + r * 0.7 + (r * 0.9 + 10);
          })
          .attr('y', d => {
            const n = nodeObjs.find(n => n.id === d.source.id || n.id === d.source);
            if (!n) return 0;
            const r = nodeRadius;
            const y = limit(n.y, r + 8, height - r - 8);
            return y - r * 0.7 - (r * 0.9) + 10;
          });
      }
    };

    simulation.on('tick', () => {
      // 使用ref中保存的边元素
      if (linkRef.current) {
        linkRef.current
          .attr('x1', d => limit(d.source.x, nodeRadius + 8, width - nodeRadius - 8))
          .attr('y1', d => limit(d.source.y, nodeRadius + 8, height - nodeRadius - 8))
          .attr('x2', d => limit(d.target.x, nodeRadius + 8, width - nodeRadius - 8))
          .attr('y2', d => limit(d.target.y, nodeRadius + 8, height - nodeRadius - 8));
      }
      
      // 更新自环元素
      updateSelfLoops();
      
      if (nodeRef.current) {
        nodeRef.current
          .attr('cx', d => limit(d.x, nodeRadius + 8, width - nodeRadius - 8))
          .attr('cy', d => limit(d.y, nodeRadius + 8, height - nodeRadius - 8));
      }
      
      // 更新节点ID标签位置
      svg.selectAll('g.node-id-labels text')
        .attr('x', d => limit(d.x, nodeRadius + 8, width - nodeRadius - 8))
        .attr('y', d => limit(d.y, nodeRadius + 8, height - nodeRadius - 8));
      
      // 更新自定义标签位置
      svg.selectAll('g.node-custom-labels text')
        .attr('x', d => limit(d.x, nodeRadius + 8, width - nodeRadius - 8))
        .attr('y', d => limit(d.y, nodeRadius + 8, height - nodeRadius - 8));
      
      // 边 label 位置
      if (linkLabelRef.current) {
        linkLabelRef.current
          .attr('x', d => (limit(d.source.x, nodeRadius + 8, width - nodeRadius - 8) + limit(d.target.x, nodeRadius + 8, width - nodeRadius - 8)) / 2)
          .attr('y', d => (limit(d.source.y, nodeRadius + 8, height - nodeRadius - 8) + limit(d.target.y, nodeRadius + 8, height - nodeRadius - 8)) / 2 - 6);
      }
    });

    return () => simulation.stop();
  };

  // 只在结构变化时重建 simulation（不包含点fixed和label状态变化）
  useEffect(() => {
    const cleanup = rebuildGraph();
    return cleanup;
  }, [width, height, chargeStrength]);

  // 专门处理节点变化（添加、删除、ID、固定状态、标签等），使用 D3 的 join 更新
  useEffect(() => {
    console.log("触发专门处理节点变化（添加、删除、ID、固定状态、标签等）的useEffect");
    if (simulationRef.current) {
      const svg = d3.select(ref.current);
      
      // 获取当前节点对象，用于保持已存在节点的位置
      const existingNodeMap = new Map();
      nodeObjsRef.current.forEach(node => {
        existingNodeMap.set(node.id, { ...node });
      });
      
      // 构建新的节点对象数组
      const newNodeObjs = nodes
        .map((n, i) => ({ ...n, idx: i }))
        .filter(n => n.id)
        .map((n, i, arr) => {
          // 如果节点已存在，保留其位置和固定状态
          if (existingNodeMap.has(n.id)) {
            const existingNode = existingNodeMap.get(n.id);
            return {
              ...n,
              x: existingNode.x,
              y: existingNode.y,
              fx: n.fixed ? (n.x !== undefined ? n.x : existingNode.x) : existingNode.fx,
              fy: n.fixed ? (n.y !== undefined ? n.y : existingNode.y) : existingNode.fy,
              fixed: n.fixed
            };
          } else {
            // 新节点，计算初始位置
            return {
              ...n,
              x: n.x ?? width / 2 + (nodeRadius * 2 + 10) * Math.cos((2 * Math.PI * i) / Math.max(1, arr.length)),
              y: n.y ?? height / 2 + (nodeRadius * 2 + 10) * Math.sin((2 * Math.PI * i) / Math.max(1, arr.length)),
              fx: n.fixed ? n.x : null,
              fy: n.fixed ? n.y : null
            };
          }
        });
      
      const newNodeIdSet = new Set(newNodeObjs.map(n => n.id));
      
      // 更新节点对象引用
      nodeObjsRef.current = newNodeObjs;
      
      // 更新力模拟中的节点数据
      simulationRef.current.nodes(newNodeObjs);
      
      // 重新设置链接力的ID访问器
      if (simulationRef.current.force('link')) {
        simulationRef.current.force('link').id(d => d.id);
      }
      
      // 更新边数据，过滤掉涉及已删除节点的边
      const newEdgesForD3 = edges
        .map(e => ({ source: e.from.trim(), target: e.to.trim(), label: e.label, color: e.color }))
        .filter(e => e.source && e.target && newNodeIdSet.has(e.source) && newNodeIdSet.has(e.target));
      
      edgesRef.current = newEdgesForD3;
      
      // 更新力模拟中的边数据
      if (simulationRef.current.force('link')) {
        simulationRef.current.force('link').links(newEdgesForD3);
      }
      
      // 更新普通边和自环边
      const normalEdges = newEdgesForD3.filter(e => e.source !== e.target);
      const selfEdges = newEdgesForD3.filter(e => e.source === e.target);
      
      // 更新普通边
      if (linkRef.current) {
        linkRef.current = linkRef.current
          .data(normalEdges, d => `${d.source.id || d.source}-${d.target.id || d.target}`)
          .join('line')
          .attr('stroke-width', edgeWidth);
      }
      
      // 更新自环边
      if (selfLoopRef.current) {
        selfLoopRef.current = selfLoopRef.current
          .data(selfEdges, d => `${d.source.id || d.source}-${d.target.id || d.target}`)
          .join('path')
          .attr('fill', 'none')
          .attr('stroke-width', edgeWidth);
      }
      
      // 更新普通边标签
      if (linkLabelRef.current) {
        linkLabelRef.current = linkLabelRef.current
          .data(normalEdges, d => `${d.source.id || d.source}-${d.target.id || d.target}`)
          .join('text')
          .attr('font-size', 14)
          .attr('fill', '#333')
          .attr('text-anchor', 'middle')
          .style('pointer-events', 'none')
          .style('user-select', 'none')
          .text(d => d.label || '');
      }
      
      // 更新自环标签
      if (selfLoopLabelRef.current) {
        selfLoopLabelRef.current = selfLoopLabelRef.current
          .data(selfEdges, d => `${d.source.id || d.source}-${d.target.id || d.target}`)
          .join('text')
          .attr('font-size', 14)
          .attr('fill', '#333')
          .attr('text-anchor', 'middle')
          .style('pointer-events', 'none')
          .style('user-select', 'none')
          .text(d => d.label || '');
      }
      
      // 更新节点
      if (nodeRef.current) {
        nodeRef.current = nodeRef.current
          .data(newNodeObjs, d => d.id)
          .join('circle')
          .attr('r', nodeRadius)
          .attr('fill', d => d.color || '#69b3a2')
          .attr('stroke', d => d.fixed ? '#000' : '#fff')
          .attr('stroke-width', d => d.fixed ? 3 : 1.5)
          .style('cursor', 'pointer')
          .style('user-select', 'none')
          .on('click', (event, d) => {
            event.stopPropagation();
            console.log('Node clicked:', d.id);
            if (onNodeClick) {
              onNodeClick(d.id);
            }
          })
          .call(d3.drag()
            .on('start', (event, d) => {
              if (!event.active) simulationRef.current.alphaTarget(0.3).restart();
              d.fx = d.x;
              d.fy = d.y;
            })
            .on('drag', (event, d) => {
              d.fx = event.x;
              d.fy = event.y;
            })
            .on('end', (event, d) => {
              if (!event.active) simulationRef.current.alphaTarget(0);
              if (!d.fixed) {
                d.fx = null;
                d.fy = null;
              }
            })
          );
      }
      
      // 更新节点ID标签
      svg.select('g.node-id-labels')
        .selectAll('text')
        .data(newNodeObjs, d => d.id)
        .join('text')
        .attr('text-anchor', 'middle')
        .attr('dy', 5)
        .attr('font-size', Math.max(12, nodeRadius))
        .style('pointer-events', 'none')
        .style('user-select', 'none')
        .text(d => d.id);
      
      // 更新自定义标签
      svg.select('g.node-custom-labels')
        .selectAll('text')
        .data(newNodeObjs, d => d.id)
        .join('text')
        .attr('text-anchor', 'start')
        .attr('dx', nodeRadius + 8)
        .attr('dy', 5)
        .attr('font-size', Math.max(12, nodeRadius - 2))
        .attr('fill', '#1976d2')
        .style('pointer-events', 'none')
        .style('user-select', 'none')
        .text(d => d.label || '');
      
      // 重新应用箭头标记
      const marker = svg.select('defs marker');
      if (marker.size() > 0 && directed) {
        const markerId = marker.attr('id');
        if (linkRef.current) {
          linkRef.current.attr('marker-end', `url(#${markerId})`);
        }
      }
      
      // 重启仿真
      simulationRef.current.alpha(0.3).restart();
    }
  }, [nodes.map(n => `${n.id}`).join(',')]); // 当节点ID列表变化时触发

  // 专门处理节点ID、固定状态、标签和nodeRadius变化，不重建整个图形
  useEffect(() => {
    console.log("触发专门处理节点ID、固定状态、标签和nodeRadius变化的useEffect");
    if (simulationRef.current && nodeObjsRef.current.length > 0) {
      const svg = d3.select(ref.current);
      
      // 首先检查是否有节点ID变化
      const currentIds = nodes.map(n => n.id);
      const existingIds = nodeObjsRef.current.map(n => n.id);
      const hasIdChanges = currentIds.some((id, i) => id !== existingIds[i]);
      
      if (hasIdChanges) {
        // 更新节点ID和相关数据
        nodeObjsRef.current.forEach((nodeObj, i) => {
          if (nodes[i]) {
            nodeObj.id = nodes[i].id;
            nodeObj.fixed = nodes[i].fixed;
            nodeObj.label = nodes[i].label;
            
            // 如果外部传入了x,y坐标，使用它们
            if (nodes[i].x !== undefined) {
              nodeObj.x = nodes[i].x;
            }
            if (nodes[i].y !== undefined) {
              nodeObj.y = nodes[i].y;
            }
            
            // 如果节点变为固定状态，设置固定位置
            if (nodes[i].fixed) {
              nodeObj.fx = nodes[i].fx !== undefined ? nodes[i].fx : nodeObj.x;
              nodeObj.fy = nodes[i].fy !== undefined ? nodes[i].fy : nodeObj.y;
            } else {
              // 如果节点变为非固定状态，清除固定位置
              nodeObj.fx = null;
              nodeObj.fy = null;
            }
          }
        });
        
        // 更新D3仿真中的节点数据
        if (simulationRef.current) {
          simulationRef.current.nodes(nodeObjsRef.current);
          // 重新设置链接力的ID访问器，确保边能正确找到更新后的节点
          if (simulationRef.current.force('link')) {
            simulationRef.current.force('link').id(d => d.id);
          }
          simulationRef.current.alpha(0.3).restart();
        }
        
        // 更新DOM中的节点ID标签
        svg.selectAll('g.node-id-labels text') // 节点ID标签
          .data(nodeObjsRef.current)
          .text(d => d.id);
        
        // 更新DOM中的自定义标签
        svg.selectAll('g.node-custom-labels text') // 自定义标签
          .data(nodeObjsRef.current)
          .text(d => d.label || '');
      } else {
        // 如果没有ID变化，只更新固定状态和标签
        nodeObjsRef.current.forEach(nodeObj => {
          const currentNode = nodes.find(n => n.id === nodeObj.id);
          if (currentNode) {
            // 如果外部传入了x,y坐标，使用它们
            if (currentNode.x !== undefined) {
              nodeObj.x = currentNode.x;
            }
            if (currentNode.y !== undefined) {
              nodeObj.y = currentNode.y;
            }
            
            // 更新固定状态
            if (currentNode.fixed && !nodeObj.fixed) {
              // 从非固定变为固定
              nodeObj.fx = currentNode.fx !== undefined ? currentNode.fx : nodeObj.x;
              nodeObj.fy = currentNode.fy !== undefined ? currentNode.fy : nodeObj.y;
              nodeObj.fixed = true;
            } else if (!currentNode.fixed && nodeObj.fixed) {
              // 从固定变为非固定
              nodeObj.fx = null;
              nodeObj.fy = null;
              nodeObj.fixed = false;
              // 重启仿真以便节点可以重新移动
              simulationRef.current.alpha(0.3).restart();
            } else if (currentNode.fixed && nodeObj.fixed) {
            } else if (!currentNode.fixed && !nodeObj.fixed) {
              // 保持非固定状态，确保没有fx/fy属性
              nodeObj.fx = null;
              nodeObj.fy = null;
            }
            
            // 更新标签
            nodeObj.label = currentNode.label;
          }
        });
        
        // 只更新DOM中的自定义标签
        svg.selectAll('g.node-custom-labels text')
          .data(nodeObjsRef.current)
          .text(d => d.label || '');
      }
      
      // 更新节点边框样式：固定节点用黑色粗边框
      if (nodeRef.current) {
        nodeRef.current
          .attr('stroke', d => d.fixed ? '#000' : '#fff')
          .attr('stroke-width', d => d.fixed ? 3 : 1.5)
          .attr('r', nodeRadius); // 动态更新节点半径
      }
      
      // 更新节点ID标签字体大小
      svg.selectAll('g.node-id-labels text')
        .attr('font-size', Math.max(12, nodeRadius));
      
      // 更新自定义标签位置和字体大小
      svg.selectAll('g.node-custom-labels text')
        .attr('dx', nodeRadius + 8)
        .attr('font-size', Math.max(12, nodeRadius - 2));
      
      // 更新仿真的力配置
      if (simulationRef.current.force('link')) {
        simulationRef.current.force('link').distance(nodeRadius * 5);
      }
      if (simulationRef.current.force('collide')) {
        simulationRef.current.force('collide').radius(nodeRadius + 8);
      }
      
      // 重启仿真以应用新的力配置
      simulationRef.current.alpha(0.3).restart();
    }
  }, [nodes.map(n => `${n.id}:${n.fixed}:${n.label || ''}`).join(','), nodeRadius]); // 在ID、固定状态、标签或nodeRadius变化时触发

  // 专门处理边变化，不重建整个图形
  useEffect(() => {
    if (simulationRef.current && nodeObjsRef.current.length > 0) {
      const svg = d3.select(ref.current);
      const nodeIdSet = new Set(nodeObjsRef.current.map(n => n.id));

      // 处理边数据
      const newEdgesForD3 = edges
        .map(e => ({ source: e.from.trim(), target: e.to.trim(), label: e.label }))
        .filter(e => e.source && e.target && nodeIdSet.has(e.source) && nodeIdSet.has(e.target));

      const normalEdges = newEdgesForD3.filter(e => e.source !== e.target);
      const selfEdges = newEdgesForD3.filter(e => e.source === e.target);

      // 更新普通边
      if (linkRef.current) {
        linkRef.current = linkRef.current
          .data(normalEdges, d => `${d.source}-${d.target}`)
          .join('line')
          .attr('stroke-width', edgeWidth);

        // 更新箭头标记
        let marker = svg.select('defs marker');
        // 如果是 directed 模式但没有 marker，则创建一个
        if (directed && marker.size() === 0) {
          let markerId = `arrowhead-${Math.random().toString(36).slice(2, 10)}`;
          svg.select('defs').remove(); // 清除旧的 defs
          svg.append('defs').append('marker')
            .attr('id', markerId)
            .attr('viewBox', '0 -5 10 10')
            .attr('refX', nodeRadius+15 - arrowSize)
            .attr('refY', 0)
            .attr('markerWidth', arrowSize)
            .attr('markerHeight', arrowSize)
            .attr('orient', 'auto')
            .append('path')
            .attr('d', 'M0,-5L10,0L0,5')
            .attr('fill', '#999');
          marker = svg.select('defs marker');
        } 
        // 如果不是 directed 模式但有 marker，则移除它
        else if (!directed && marker.size() > 0) {
          svg.select('defs').remove();
        }

        // 应用或移除箭头标记
        if (marker.size() > 0 && directed) {
          // 动态更新箭头大小
          marker
            .attr('markerWidth', arrowSize)
            .attr('markerHeight', arrowSize)
            .attr('refX', nodeRadius+15 - arrowSize);
          const markerId = marker.attr('id');
          linkRef.current.attr('marker-end', `url(#${markerId})`);
        } else {
          linkRef.current.attr('marker-end', null);
        }
      }

      // 更新自环
      if (selfLoopRef.current) {
        selfLoopRef.current = selfLoopRef.current
          .data(selfEdges, d => `${d.source}-${d.target}`)
          .join('path')
          .attr('fill', 'none')
          .attr('stroke-width', edgeWidth);
      }

      // 更新边标签
      if (linkLabelRef.current) {
        linkLabelRef.current = linkLabelRef.current
          .data(normalEdges, d => `${d.source}-${d.target}`)
          .join('text')
          .attr('font-size', 14)
          .attr('fill', '#333')
          .attr('text-anchor', 'middle')
          .style('pointer-events', 'none')
          .style('user-select', 'none')
          .text(d => d.label || '');
      }

      // 更新自环标签
      if (selfLoopLabelRef.current) {
        selfLoopLabelRef.current = selfLoopLabelRef.current
          .data(selfEdges, d => `${d.source}-${d.target}`)
          .join('text')
          .attr('font-size', 14)
          .attr('fill', '#333')
          .attr('text-anchor', 'middle')
          .style('pointer-events', 'none')
          .style('user-select', 'none')
          .text(d => d.label || '');
      }

      // 更新仿真的边数据
      if (simulationRef.current.force('link')) {
        simulationRef.current.force('link').links(newEdgesForD3);
        simulationRef.current.alpha(0.3).restart();
      }

      // 保存当前边数据以供后续比较
      edgesRef.current = newEdgesForD3;
    }
  }, [
    edges.map(e => `${e.from}-${e.to}-${e.label || ''}`).join(','),
    directed,
    arrowSize,
    edgeWidth,
    nodes.map(n => n.id).join(',')
  ]); // 在边、方向性、节点ID、arrowSize、edgeWidth变化时触发

  // 响应节点颜色变化时刷新颜色
  useEffect(() => {
    const svg = d3.select(ref.current);
    const nodeObjs = nodeObjsRef.current;
    
    // 首先更新 nodeObjsRef 中的颜色数据
    nodeObjs.forEach(nodeObj => {
      const currentNode = nodes.find(n => n.id === nodeObj.id);
      if (currentNode && currentNode.color) {
        nodeObj.color = currentNode.color;
      }
    });
    
    // 然后更新 DOM 中的颜色 - 使用ref保持一致性
    if (nodeRef.current) {
      nodeRef.current.attr('fill', d => d.color || '#69b3a2');
    }

    const selfLoop = selfLoopRef.current;
    const linkLabel = linkLabelRef.current;

    // 更新普通边的颜色
    if (linkRef.current) {
      linkRef.current
        .attr('stroke', d => {
          const edgeData = edges.find(e => 
            e.from.trim() === (typeof d.source === 'string' ? d.source : d.source.id) && 
            e.to.trim() === (typeof d.target === 'string' ? d.target : d.target.id)
          );
          return edgeData?.color || '#999';
        })
        .attr('stroke-width', edgeWidth);
    }

    // 更新自环的颜色
    if (selfLoopRef.current) {
      selfLoopRef.current
        .attr('stroke', d => {
          const edgeData = edges.find(e => 
            e.from.trim() === (typeof d.source === 'string' ? d.source : d.source.id) && 
            e.to.trim() === (typeof d.target === 'string' ? d.target : d.target.id)
          );
          return edgeData?.color || '#999';
        })
        .attr('stroke-width', edgeWidth);
    }
  }, [nodes.map(n => `${n.id}:${n.color}`).join(','), edges.map(e => `${e.from}-${e.to}:${e.color || ''}`).join(','), edgeWidth]);

  return <svg ref={ref} style={{ border: '1px solid #ccc', margin: '16px 0', userSelect: 'none', WebkitUserSelect: 'none', MozUserSelect: 'none', msUserSelect: 'none' }}></svg>;
}